﻿
using System;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.Windows.Forms;

namespace QuanLyNhapVaBanHangTapHoa
{
    public partial class FormThongKe : Form
    {
        private readonly string _connectionStringFull =
            "Data Source=LAPTOP-QM4J7II6;Initial Catalog=QuanLyNhapVaBanHangTapHoa;Integrated Security=True;Encrypt=True;TrustServerCertificate=True";

        private readonly string _connectionStringFallback =
            "Data Source=LAPTOP-QM4J7II6;Initial Catalog=QuanLyNhapVaBanHangTapHoa;Integrated Security=True";

        private string _connectionString;
        private DataTable _dtThongKe;

        public FormThongKe()
        {
            InitializeComponent();
            this.Load += FormThongKe_Load;

            // initialize hint text
            txtSearch.Text = "Tìm theo Mã/Tên/Loại";
            txtSearch.ForeColor = System.Drawing.Color.Gray;
        }

        private void FormThongKe_Load(object sender, EventArgs e)
        {
            _connectionString = GetWorkingConnectionString();
            if (string.IsNullOrEmpty(_connectionString))
            {
                MessageBox.Show("Không xác định được chuỗi kết nối hợp lệ.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            LoadData();
        }

        private string GetWorkingConnectionString()
        {
            if (!string.IsNullOrEmpty(_connectionString)) return _connectionString;

            try
            {
                using (var conn = new SqlConnection(_connectionStringFull))
                {
                    conn.Open();
                    conn.Close();
                }
                _connectionString = _connectionStringFull;
                return _connectionString;
            }
            catch (SqlException exFull)
            {
                var msg = exFull.Message ?? string.Empty;
                if (msg.IndexOf("Keyword not supported", StringComparison.OrdinalIgnoreCase) >= 0
                    || msg.IndexOf("TrustServerCertificate", StringComparison.OrdinalIgnoreCase) >= 0
                    || msg.IndexOf("Encrypt", StringComparison.OrdinalIgnoreCase) >= 0)
                {
                    try
                    {
                        using (var conn = new SqlConnection(_connectionStringFallback))
                        {
                            conn.Open();
                            conn.Close();
                        }
                        _connectionString = _connectionStringFallback;
                        return _connectionString;
                    }
                    catch (Exception exFallback)
                    {
                        MessageBox.Show("Không thể kết nối với SQL Server bằng chuỗi fallback: " + exFallback.Message, "Lỗi kết nối", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return null;
                    }
                }

                MessageBox.Show("Lỗi khi thử chuỗi đầy đủ: " + exFull.Message, "Lỗi kết nối", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return null;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi kiểm tra chuỗi kết nối: " + ex.Message, "Lỗi kết nối", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return null;
            }
        }

        // Load product statistics (MaSanPham, TenSanPham, SoLuong, Loai)
        private void LoadData(string filter = null)
        {
            try
            {
                using (var conn = new SqlConnection(_connectionString))
                {
                    var sql = "SELECT MaSanPham, TenSanPham, SoLuongLon AS SoLuong, TenLoai AS Loai FROM SanPham";
                    if (!string.IsNullOrWhiteSpace(filter))
                    {
                        sql += " WHERE MaSanPham LIKE @q OR TenSanPham LIKE @q OR TenLoai LIKE @q";
                    }

                    using (var da = new SqlDataAdapter(sql, conn))
                    {
                        if (!string.IsNullOrWhiteSpace(filter))
                        {
                            da.SelectCommand.Parameters.AddWithValue("@q", "%" + filter.Trim() + "%");
                        }

                        _dtThongKe = new DataTable();
                        da.Fill(_dtThongKe);
                        dgvThongKe.DataSource = _dtThongKe;
                    }
                }

                FormatGrid();
            }
            catch (SqlException sqlEx)
            {
                MessageBox.Show("Lỗi khi tải dữ liệu (SQL): " + sqlEx.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi tải dữ liệu: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void FormatGrid()
        {
            dgvThongKe.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvThongKe.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvThongKe.MultiSelect = false;
            dgvThongKe.ReadOnly = true;

            if (dgvThongKe.Columns["MaSanPham"] != null) dgvThongKe.Columns["MaSanPham"].HeaderText = "Mã Sản Phẩm";
            if (dgvThongKe.Columns["TenSanPham"] != null) dgvThongKe.Columns["TenSanPham"].HeaderText = "Tên Sản Phẩm";
            if (dgvThongKe.Columns["SoLuong"] != null) dgvThongKe.Columns["SoLuong"].HeaderText = "Số Lượng";
            if (dgvThongKe.Columns["Loai"] != null) dgvThongKe.Columns["Loai"].HeaderText = "Loại";
        }

        // Placeholder-like behaviour for .NET Framework 4.5
        private void txtSearch_Enter(object sender, EventArgs e)
        {
            if (txtSearch.ForeColor == System.Drawing.Color.Gray && txtSearch.Text == "Tìm theo Mã/Tên/Loại")
            {
                txtSearch.Text = "";
                txtSearch.ForeColor = System.Drawing.Color.Black;
            }
        }

        private void txtSearch_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtSearch.Text))
            {
                txtSearch.Text = "Tìm theo Mã/Tên/Loại";
                txtSearch.ForeColor = System.Drawing.Color.Gray;
            }
        }

        // Search button click
        private void btnSearch_Click(object sender, EventArgs e)
        {
            var q = txtSearch.ForeColor == System.Drawing.Color.Gray ? "" : txtSearch.Text;
            LoadData(q);
        }

        // Enter key triggers search
        private void txtSearch_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.Handled = true;
                e.SuppressKeyPress = true;
                var q = txtSearch.ForeColor == System.Drawing.Color.Gray ? "" : txtSearch.Text;
                LoadData(q);
            }
        }
    }
}