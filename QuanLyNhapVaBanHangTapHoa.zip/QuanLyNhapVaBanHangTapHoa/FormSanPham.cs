﻿
using System;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.Windows.Forms;

namespace QuanLyNhapVaBanHangTapHoa
{
    public partial class FormSanPham : Form
    {
        // Chuỗi đầy đủ (theo yêu cầu)
        private readonly string _connectionStringFull =
            "Data Source=LAPTOP-QM4J7II6;Initial Catalog=QuanLyNhapVaBanHangTapHoa;Integrated Security=True;Encrypt=True;TrustServerCertificate=True";

        // Fallback nếu driver không chấp nhận một số keyword
        private readonly string _connectionStringFallback =
            "Data Source=LAPTOP-QM4J7II6;Initial Catalog=QuanLyNhapVaBanHangTapHoa;Integrated Security=True";

        // Chuỗi đang hoạt động (cached)
        private string _connectionString;

        private DataTable _dtSanPham;

        public FormSanPham()
        {
            InitializeComponent();
            this.Load += FormSanPham_Load;
        }

        private void FormSanPham_Load(object sender, EventArgs e)
        {
            // Lấy chuỗi hoạt động trước khi load dữ liệu
            _connectionString = GetWorkingConnectionString();
            if (string.IsNullOrEmpty(_connectionString))
            {
                MessageBox.Show("Không thể xác định chuỗi kết nối hợp lệ. Kiểm tra cấu hình SQL Server.", "Lỗi kết nối", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            LoadData();
        }

        // Thử chuỗi đầy đủ, nếu lỗi keyword thì dùng fallback
        private string GetWorkingConnectionString()
        {
            // Nếu đã có chuỗi hoạt động, trả về nó
            if (!string.IsNullOrEmpty(_connectionString))
                return _connectionString;

            // 1) Thử chuỗi đầy đủ
            try
            {
                using (var conn = new SqlConnection(_connectionStringFull))
                {
                    conn.Open();
                    conn.Close();
                }
                _connectionString = _connectionStringFull;
                return _connectionString;
            }
            catch (SqlException exFull)
            {
                // Nếu lỗi liên quan đến keyword không hỗ trợ, thử fallback
                var msg = exFull.Message ?? string.Empty;
                if (msg.IndexOf("Keyword not supported", StringComparison.OrdinalIgnoreCase) >= 0
                    || msg.IndexOf("TrustServerCertificate", StringComparison.OrdinalIgnoreCase) >= 0
                    || msg.IndexOf("Encrypt", StringComparison.OrdinalIgnoreCase) >= 0)
                {
                    try
                    {
                        using (var conn = new SqlConnection(_connectionStringFallback))
                        {
                            conn.Open();
                            conn.Close();
                        }
                        _connectionString = _connectionStringFallback;
                        return _connectionString;
                    }
                    catch (Exception exFallback)
                    {
                        MessageBox.Show("Không thể kết nối với SQL Server bằng chuỗi fallback: " + exFallback.Message, "Lỗi kết nối", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return null;
                    }
                }

                // Các lỗi khác: báo và dừng
                MessageBox.Show("Lỗi khi thử chuỗi kết nối đầy đủ: " + exFull.Message, "Lỗi kết nối", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return null;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi kiểm tra chuỗi kết nối: " + ex.Message, "Lỗi kết nối", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return null;
            }
        }

        private void LoadData()
        {
            try
            {
                using (var conn = new SqlConnection(_connectionString))
                {
                    var sql = "SELECT MaSanPham, TenSanPham, SoLuongLon, GiaBan, DonViTinh, TenLoai FROM SanPham";
                    using (var da = new SqlDataAdapter(sql, conn))
                    {
                        _dtSanPham = new DataTable();
                        da.Fill(_dtSanPham);
                        dgvSanPham.DataSource = _dtSanPham;
                    }
                }

                FormatGrid();
                ClearInputs();
            }
            catch (SqlException sqlEx)
            {
                MessageBox.Show("Lỗi khi tải dữ liệu (SQL): " + sqlEx.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi tải dữ liệu: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void FormatGrid()
        {
            dgvSanPham.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvSanPham.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvSanPham.MultiSelect = false;
            dgvSanPham.ReadOnly = true;
        }

        private void ClearInputs()
        {
            txtMaSanPham.Text = "";
            txtTenSanPham.Text = "";
            txtSoLuongLon.Text = "0";
            txtGiaBan.Text = "0.00";
            txtDonViTinh.Text = "";
            txtTenLoai.Text = "";
            txtMaSanPham.Enabled = true;
        }

        private void dgvSanPham_SelectionChanged(object sender, EventArgs e)
        {
            if (dgvSanPham.CurrentRow == null) return;

            var row = dgvSanPham.CurrentRow;
            txtMaSanPham.Text = Convert.ToString(row.Cells["MaSanPham"].Value);
            txtTenSanPham.Text = Convert.ToString(row.Cells["TenSanPham"].Value);
            txtSoLuongLon.Text = Convert.ToString(row.Cells["SoLuongLon"].Value);
            txtGiaBan.Text = Convert.ToString(row.Cells["GiaBan"].Value);
            txtDonViTinh.Text = Convert.ToString(row.Cells["DonViTinh"].Value);
            txtTenLoai.Text = Convert.ToString(row.Cells["TenLoai"].Value);

            txtMaSanPham.Enabled = false;
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            var ma = txtMaSanPham.Text.Trim();
            var ten = txtTenSanPham.Text.Trim();

            if (string.IsNullOrEmpty(ma) || string.IsNullOrEmpty(ten))
            {
                MessageBox.Show("Mã sản phẩm và Tên sản phẩm không được để trống.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!int.TryParse(txtSoLuongLon.Text.Trim(), out int soLuong))
            {
                MessageBox.Show("Số lượng lớn phải là số nguyên.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!decimal.TryParse(txtGiaBan.Text.Trim(), NumberStyles.Number, CultureInfo.CurrentCulture, out decimal giaBan))
            {
                MessageBox.Show("Giá bán không đúng định dạng.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            var donVi = txtDonViTinh.Text.Trim();
            var tenLoai = txtTenLoai.Text.Trim();

            try
            {
                using (var conn = new SqlConnection(_connectionString))
                using (var cmd = conn.CreateCommand())
                {
                    cmd.CommandText = "INSERT INTO SanPham (MaSanPham, TenSanPham, SoLuongLon, GiaBan, DonViTinh, TenLoai) " +
                                      "VALUES (@Ma, @Ten, @SoLuong, @Gia, @DonVi, @TenLoai)";
                    cmd.Parameters.AddWithValue("@Ma", ma);
                    cmd.Parameters.AddWithValue("@Ten", ten);
                    cmd.Parameters.AddWithValue("@SoLuong", soLuong);
                    cmd.Parameters.AddWithValue("@Gia", giaBan);
                    cmd.Parameters.AddWithValue("@DonVi", string.IsNullOrEmpty(donVi) ? (object)DBNull.Value : donVi);
                    cmd.Parameters.AddWithValue("@TenLoai", string.IsNullOrEmpty(tenLoai) ? (object)DBNull.Value : tenLoai);

                    conn.Open();
                    cmd.ExecuteNonQuery();
                }

                LoadData();
                MessageBox.Show("Thêm sản phẩm thành công.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (SqlException ex) when (ex.Number == 2627)
            {
                MessageBox.Show("Mã sản phẩm đã tồn tại.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi thêm: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            var ma = txtMaSanPham.Text.Trim();
            if (string.IsNullOrEmpty(ma))
            {
                MessageBox.Show("Chọn sản phẩm cần sửa.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            var ten = txtTenSanPham.Text.Trim();
            if (!int.TryParse(txtSoLuongLon.Text.Trim(), out int soLuong))
            {
                MessageBox.Show("Số lượng lớn phải là số nguyên.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!decimal.TryParse(txtGiaBan.Text.Trim(), NumberStyles.Number, CultureInfo.CurrentCulture, out decimal giaBan))
            {
                MessageBox.Show("Giá bán không đúng định dạng.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            var donVi = txtDonViTinh.Text.Trim();
            var tenLoai = txtTenLoai.Text.Trim();

            try
            {
                using (var conn = new SqlConnection(_connectionString))
                using (var cmd = conn.CreateCommand())
                {
                    cmd.CommandText = "UPDATE SanPham SET TenSanPham=@Ten, SoLuongLon=@SoLuong, GiaBan=@Gia, DonViTinh=@DonVi, TenLoai=@TenLoai " +
                                      "WHERE MaSanPham=@Ma";
                    cmd.Parameters.AddWithValue("@Ten", ten);
                    cmd.Parameters.AddWithValue("@SoLuong", soLuong);
                    cmd.Parameters.AddWithValue("@Gia", giaBan);
                    cmd.Parameters.AddWithValue("@DonVi", string.IsNullOrEmpty(donVi) ? (object)DBNull.Value : donVi);
                    cmd.Parameters.AddWithValue("@TenLoai", string.IsNullOrEmpty(tenLoai) ? (object)DBNull.Value : tenLoai);
                    cmd.Parameters.AddWithValue("@Ma", ma);

                    conn.Open();
                    var rows = cmd.ExecuteNonQuery();
                    if (rows == 0)
                        MessageBox.Show("Không tìm thấy sản phẩm để cập nhật.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    else
                    {
                        LoadData();
                        MessageBox.Show("Cập nhật thành công.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi sửa: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            var ma = txtMaSanPham.Text.Trim();
            if (string.IsNullOrEmpty(ma))
            {
                MessageBox.Show("Chọn sản phẩm cần xóa.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (MessageBox.Show("Bạn có chắc muốn xóa sản phẩm này?", "Xác nhận", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes)
                return;

            try
            {
                using (var conn = new SqlConnection(_connectionString))
                using (var cmd = conn.CreateCommand())
                {
                    cmd.CommandText = "DELETE FROM SanPham WHERE MaSanPham = @Ma";
                    cmd.Parameters.AddWithValue("@Ma", ma);
                    conn.Open();
                    var rows = cmd.ExecuteNonQuery();
                    if (rows == 0)
                        MessageBox.Show("Không tìm thấy sản phẩm để xóa.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    else
                    {
                        LoadData();
                        MessageBox.Show("Xóa thành công.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi xóa: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnDong_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}