﻿
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace QuanLyNhapVaBanHangTapHoa
{
    partial class DangNhap
    {
        private IContainer components = null;

        private Label lblHeader;
        private Label lblUsername;
        private Label lblPassword;
        private TextBox txtUsername;
        private TextBox txtPassword;
        private Button btnDangNhap;
        private Button btnQuenMatKhau; // renamed
        private CheckBox chkShowPassword;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.components = new Container();

            this.lblHeader = new Label();
            this.lblUsername = new Label();
            this.lblPassword = new Label();
            this.txtUsername = new TextBox();
            this.txtPassword = new TextBox();
            this.btnDangNhap = new Button();
            this.btnQuenMatKhau = new Button();
            this.chkShowPassword = new CheckBox();

            // Form
            this.ClientSize = new Size(420, 260);
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "Đăng nhập - Quản lý cửa hàng";

            // lblHeader
            this.lblHeader.Text = "ĐĂNG NHẬP";
            this.lblHeader.Font = new Font("Segoe UI", 14F, FontStyle.Bold);
            this.lblHeader.TextAlign = ContentAlignment.MiddleCenter;
            this.lblHeader.Size = new Size(400, 40);
            this.lblHeader.Location = new Point(10, 10);

            // lblUsername
            this.lblUsername.Text = "Tài khoản";
            this.lblUsername.Location = new Point(30, 70);
            this.lblUsername.Size = new Size(100, 22);

            // txtUsername
            this.txtUsername.Location = new Point(140, 68);
            this.txtUsername.Size = new Size(240, 24);
            this.txtUsername.Name = "txtUsername";

            // lblPassword
            this.lblPassword.Text = "Mật khẩu";
            this.lblPassword.Location = new Point(30, 110);
            this.lblPassword.Size = new Size(100, 22);

            // txtPassword
            this.txtPassword.Location = new Point(140, 108);
            this.txtPassword.Size = new Size(240, 24);
            this.txtPassword.Name = "txtPassword";

            // chkShowPassword
            this.chkShowPassword.Text = "Hiện mật khẩu";
            this.chkShowPassword.Location = new Point(140, 138);
            this.chkShowPassword.Size = new Size(120, 22);

            // btnDangNhap
            this.btnDangNhap.Text = "Đăng nhập";
            this.btnDangNhap.Location = new Point(140, 170);
            this.btnDangNhap.Size = new Size(110, 36);
            this.btnDangNhap.Name = "btnDangNhap";

            // btnQuenMatKhau (replaces btnDangKi)
            this.btnQuenMatKhau.Text = "Quên mật khẩu";
            this.btnQuenMatKhau.Location = new Point(270, 170);
            this.btnQuenMatKhau.Size = new Size(110, 36);
            this.btnQuenMatKhau.Name = "btnQuenMatKhau";

            // Add controls
            this.Controls.Add(this.lblHeader);
            this.Controls.Add(this.lblUsername);
            this.Controls.Add(this.txtUsername);
            this.Controls.Add(this.lblPassword);
            this.Controls.Add(this.txtPassword);
            this.Controls.Add(this.chkShowPassword);
            this.Controls.Add(this.btnDangNhap);
            this.Controls.Add(this.btnQuenMatKhau);
        }
    }
}