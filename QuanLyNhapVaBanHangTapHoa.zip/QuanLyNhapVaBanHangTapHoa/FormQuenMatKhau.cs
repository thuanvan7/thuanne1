﻿
using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace QuanLyNhapVaBanHangTapHoa
{
    public partial class QuenMatKhau : Form
    {
        private readonly string _connectionString =
            "Data Source=LAPTOP-QM4J7II6;Initial Catalog=QuanLyNhapVaBanHangTapHoa;Integrated Security=True";

        public QuenMatKhau()
        {
            InitializeComponent();
            btnReset.Click += BtnReset_Click;
            btnCancel.Click += BtnCancel_Click;
            chkShow.CheckedChanged += ChkShow_CheckedChanged;
        }

        private void ChkShow_CheckedChanged(object sender, EventArgs e)
        {
            var show = chkShow.Checked;
            txtNewPassword.UseSystemPasswordChar = !show;
            txtConfirm.UseSystemPasswordChar = !show;
        }

        private void BtnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        // Basic reset: verify username exists and email matches, then update password
        private void BtnReset_Click(object sender, EventArgs e)
        {
            var user = txtUsername.Text.Trim();
            var email = txtEmail.Text.Trim();
            var newPass = txtNewPassword.Text;
            var confirm = txtConfirm.Text;

            if (string.IsNullOrEmpty(user) || string.IsNullOrEmpty(email) || string.IsNullOrEmpty(newPass))
            {
                MessageBox.Show("Vui lòng nhập đầy đủ thông tin.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (newPass != confirm)
            {
                MessageBox.Show("Mật khẩu xác nhận không khớp.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                using (var conn = new SqlConnection(_connectionString))
                using (var cmd = conn.CreateCommand())
                {
                    conn.Open();

                    // verify username + email
                    cmd.CommandText = "SELECT COUNT(*) FROM TaiKhoan WHERE TaiKhoan = @user AND Email = @Email";
                    cmd.Parameters.AddWithValue("@user", user);
                    cmd.Parameters.AddWithValue("@Email", email);

                    var exists = Convert.ToInt32(cmd.ExecuteScalar() ?? 0);
                    if (exists == 0)
                    {
                        MessageBox.Show("Không tìm thấy tài khoản với thông tin cung cấp.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }

                    // update password
                    cmd.Parameters.Clear();
                    cmd.CommandText = "UPDATE TaiKhoan SET MatKhau = @pass WHERE TaiKhoan = @user";
                    cmd.Parameters.AddWithValue("@pass", newPass);
                    cmd.Parameters.AddWithValue("@user", user);
                    cmd.ExecuteNonQuery();

                    MessageBox.Show("Đặt lại mật khẩu thành công.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi đặt lại mật khẩu: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}