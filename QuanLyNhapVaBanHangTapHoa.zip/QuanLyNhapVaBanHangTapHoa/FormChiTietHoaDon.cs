﻿
using System;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.Windows.Forms;

namespace QuanLyNhapVaBanHangTapHoa
{
    public partial class FormChiTietHoaDon : Form
    {
        private readonly string _connectionStringFull =
            "Data Source=LAPTOP-QM4J7II6;Initial Catalog=QuanLyNhapVaBanHangTapHoa;Integrated Security=True;Encrypt=True;TrustServerCertificate=True";

        private readonly string _connectionStringFallback =
            "Data Source=LAPTOP-QM4J7II6;Initial Catalog=QuanLyNhapVaBanHangTapHoa;Integrated Security=True";

        private string _connectionString;
        private DataTable _dtChiTiet;
        private DataTable _dtLookupHoaDon;
        private DataTable _dtLookupSanPham;

        private readonly string _preselectMaHoaDon;
        private readonly string _preselectMaSanPham;

        public FormChiTietHoaDon(string preselectMaHoaDon = null, string preselectMaSanPham = null)
        {
            InitializeComponent();
            _preselectMaHoaDon = preselectMaHoaDon;
            _preselectMaSanPham = preselectMaSanPham;
            this.Load += FormChiTietHoaDon_Load;
        }

        private void FormChiTietHoaDon_Load(object sender, EventArgs e)
        {
            _connectionString = GetWorkingConnectionString();
            if (string.IsNullOrEmpty(_connectionString))
            {
                MessageBox.Show("Không thể xác định chuỗi kết nối hợp lệ.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            LoadLookupData();
            LoadData();
        }

        private string GetWorkingConnectionString()
        {
            if (!string.IsNullOrEmpty(_connectionString)) return _connectionString;

            try
            {
                using (var conn = new SqlConnection(_connectionStringFull))
                {
                    conn.Open();
                    conn.Close();
                }
                _connectionString = _connectionStringFull;
                return _connectionString;
            }
            catch (SqlException exFull)
            {
                var msg = exFull.Message ?? string.Empty;
                if (msg.IndexOf("Keyword not supported", StringComparison.OrdinalIgnoreCase) >= 0
                    || msg.IndexOf("TrustServerCertificate", StringComparison.OrdinalIgnoreCase) >= 0
                    || msg.IndexOf("Encrypt", StringComparison.OrdinalIgnoreCase) >= 0)
                {
                    try
                    {
                        using (var conn = new SqlConnection(_connectionStringFallback))
                        {
                            conn.Open();
                            conn.Close();
                        }
                        _connectionString = _connectionStringFallback;
                        return _connectionString;
                    }
                    catch (Exception exFallback)
                    {
                        MessageBox.Show("Không thể kết nối với SQL Server bằng chuỗi fallback: " + exFallback.Message, "Lỗi kết nối", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return null;
                    }
                }

                MessageBox.Show("Lỗi khi thử chuỗi đầy đủ: " + exFull.Message, "Lỗi kết nối", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return null;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi kiểm tra chuỗi kết nối: " + ex.Message, "Lỗi kết nối", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return null;
            }
        }

        private void LoadLookupData()
        {
            try
            {
                using (var conn = new SqlConnection(_connectionString))
                {
                    var sqlHoaDon = "SELECT MaHoaDon FROM HoaDon";
                    using (var da = new SqlDataAdapter(sqlHoaDon, conn))
                    {
                        _dtLookupHoaDon = new DataTable();
                        da.Fill(_dtLookupHoaDon);
                    }

                    var sqlSanPham = "SELECT MaSanPham, TenSanPham FROM SanPham";
                    using (var da2 = new SqlDataAdapter(sqlSanPham, conn))
                    {
                        _dtLookupSanPham = new DataTable();
                        da2.Fill(_dtLookupSanPham);
                    }
                }

                cboMaHoaDon.DisplayMember = "MaHoaDon";
                cboMaHoaDon.ValueMember = "MaHoaDon";
                cboMaHoaDon.DataSource = _dtLookupHoaDon;

                if (_dtLookupSanPham != null && !_dtLookupSanPham.Columns.Contains("Display"))
                    _dtLookupSanPham.Columns.Add("Display", typeof(string), "MaSanPham + ' - ' + TenSanPham");

                cboMaSanPham.DisplayMember = "Display";
                cboMaSanPham.ValueMember = "MaSanPham";
                cboMaSanPham.DataSource = _dtLookupSanPham;

                if (!string.IsNullOrEmpty(_preselectMaHoaDon))
                {
                    try { cboMaHoaDon.SelectedValue = _preselectMaHoaDon; } catch { }
                }

                if (!string.IsNullOrEmpty(_preselectMaSanPham))
                {
                    try { cboMaSanPham.SelectedValue = _preselectMaSanPham; } catch { }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi tải dữ liệu tra cứu: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void LoadData()
        {
            try
            {
                using (var conn = new SqlConnection(_connectionString))
                {
                    var sql = "SELECT MaChiTietHoaDon, MaHoaDon, MaSanPham, SoLuong, DonGia, ThanhTien FROM ChiTietHoaDon";
                    using (var da = new SqlDataAdapter(sql, conn))
                    {
                        _dtChiTiet = new DataTable();
                        da.Fill(_dtChiTiet);
                        dgvChiTiet.DataSource = _dtChiTiet;
                    }
                }

                FormatGrid();
                ClearInputs();

                if (!string.IsNullOrEmpty(_preselectMaHoaDon) && _dtChiTiet != null)
                {
                    for (int i = 0; i < _dtChiTiet.Rows.Count; i++)
                    {
                        if (string.Equals(Convert.ToString(_dtChiTiet.Rows[i]["MaHoaDon"]), _preselectMaHoaDon, StringComparison.OrdinalIgnoreCase))
                        {
                            dgvChiTiet.ClearSelection();
                            if (i < dgvChiTiet.Rows.Count) dgvChiTiet.Rows[i].Selected = true;
                            dgvChiTiet.FirstDisplayedScrollingRowIndex = i;
                            break;
                        }
                    }
                }
            }
            catch (SqlException sqlEx)
            {
                MessageBox.Show("Lỗi khi tải dữ liệu (SQL): " + sqlEx.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi tải dữ liệu: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void FormatGrid()
        {
            dgvChiTiet.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvChiTiet.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvChiTiet.MultiSelect = false;
            dgvChiTiet.ReadOnly = true;
        }

        private void ClearInputs()
        {
            txtMaChiTiet.Text = "";
            if (cboMaHoaDon.Items.Count > 0) cboMaHoaDon.SelectedIndex = -1;
            if (cboMaSanPham.Items.Count > 0) cboMaSanPham.SelectedIndex = -1;
            txtSoLuong.Text = "0";
            txtDonGia.Text = "0.00";
            txtThanhTien.Text = "0.00";
            txtMaChiTiet.Enabled = true;

            if (!string.IsNullOrEmpty(_preselectMaHoaDon))
            {
                try { cboMaHoaDon.SelectedValue = _preselectMaHoaDon; } catch { }
            }
            if (!string.IsNullOrEmpty(_preselectMaSanPham))
            {
                try { cboMaSanPham.SelectedValue = _preselectMaSanPham; } catch { }
            }
        }

        private void dgvChiTiet_SelectionChanged(object sender, EventArgs e)
        {
            if (dgvChiTiet.CurrentRow == null) return;

            var row = dgvChiTiet.CurrentRow;
            txtMaChiTiet.Text = Convert.ToString(row.Cells["MaChiTietHoaDon"].Value);

            var maHD = Convert.ToString(row.Cells["MaHoaDon"].Value);
            var maSP = Convert.ToString(row.Cells["MaSanPham"].Value);
            try { cboMaHoaDon.SelectedValue = maHD; } catch { cboMaHoaDon.SelectedIndex = -1; }
            try { cboMaSanPham.SelectedValue = maSP; } catch { cboMaSanPham.SelectedIndex = -1; }

            txtSoLuong.Text = Convert.ToString(row.Cells["SoLuong"].Value);
            txtDonGia.Text = Convert.ToString(row.Cells["DonGia"].Value);
            txtThanhTien.Text = Convert.ToString(row.Cells["ThanhTien"].Value);

            txtMaChiTiet.Enabled = false;
        }

        private void RecalculateThanhTien()
        {
            if (!int.TryParse(txtSoLuong.Text.Trim(), out int soLuong)) soLuong = 0;
            if (!decimal.TryParse(txtDonGia.Text.Trim(), NumberStyles.Number, CultureInfo.CurrentCulture, out decimal donGia)) donGia = 0m;
            var thanh = soLuong * donGia;
            txtThanhTien.Text = thanh.ToString("0.00");
        }

        private void txtSoLuong_TextChanged(object sender, EventArgs e)
        {
            RecalculateThanhTien();
        }

        private void txtDonGia_TextChanged(object sender, EventArgs e)
        {
            RecalculateThanhTien();
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            var maCT = txtMaChiTiet.Text.Trim();
            var maHD = cboMaHoaDon.SelectedValue as string ?? cboMaHoaDon.Text.Trim();
            var maSP = cboMaSanPham.SelectedValue as string ?? cboMaSanPham.Text.Trim();

            if (string.IsNullOrEmpty(maCT) || string.IsNullOrEmpty(maHD) || string.IsNullOrEmpty(maSP))
            {
                MessageBox.Show("Mã chi tiết, Mã Hóa Đơn và Mã Sản Phẩm không được để trống.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!int.TryParse(txtSoLuong.Text.Trim(), out int soLuong))
            {
                MessageBox.Show("Số lượng phải là số nguyên.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!decimal.TryParse(txtDonGia.Text.Trim(), NumberStyles.Number, CultureInfo.CurrentCulture, out decimal donGia))
            {
                MessageBox.Show("Đơn giá không đúng định dạng.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            var thanhTien = soLuong * donGia;

            try
            {
                using (var conn = new SqlConnection(_connectionString))
                using (var cmd = conn.CreateCommand())
                {
                    cmd.CommandText = "INSERT INTO ChiTietHoaDon (MaChiTietHoaDon, MaHoaDon, MaSanPham, SoLuong, DonGia, ThanhTien) " +
                                      "VALUES (@MaCT, @MaHD, @MaSP, @SoLuong, @DonGia, @ThanhTien)";
                    cmd.Parameters.AddWithValue("@MaCT", maCT);
                    cmd.Parameters.AddWithValue("@MaHD", maHD);
                    cmd.Parameters.AddWithValue("@MaSP", maSP);
                    cmd.Parameters.AddWithValue("@SoLuong", soLuong);
                    cmd.Parameters.AddWithValue("@DonGia", donGia);
                    cmd.Parameters.AddWithValue("@ThanhTien", thanhTien);

                    conn.Open();
                    cmd.ExecuteNonQuery();
                }

                LoadData();
                MessageBox.Show("Thêm chi tiết hóa đơn thành công.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (SqlException ex) when (ex.Number == 2627)
            {
                MessageBox.Show("Mã chi tiết đã tồn tại.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi thêm: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            var maCT = txtMaChiTiet.Text.Trim();
            if (string.IsNullOrEmpty(maCT))
            {
                MessageBox.Show("Chọn chi tiết cần sửa.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            var maHD = cboMaHoaDon.SelectedValue as string ?? cboMaHoaDon.Text.Trim();
            var maSP = cboMaSanPham.SelectedValue as string ?? cboMaSanPham.Text.Trim();

            if (!int.TryParse(txtSoLuong.Text.Trim(), out int soLuong))
            {
                MessageBox.Show("Số lượng phải là số nguyên.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!decimal.TryParse(txtDonGia.Text.Trim(), NumberStyles.Number, CultureInfo.CurrentCulture, out decimal donGia))
            {
                MessageBox.Show("Đơn giá không đúng định dạng.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            var thanhTien = soLuong * donGia;

            try
            {
                using (var conn = new SqlConnection(_connectionString))
                using (var cmd = conn.CreateCommand())
                {
                    cmd.CommandText = "UPDATE ChiTietHoaDon SET MaHoaDon=@MaHD, MaSanPham=@MaSP, SoLuong=@SoLuong, DonGia=@DonGia, ThanhTien=@ThanhTien " +
                                      "WHERE MaChiTietHoaDon=@MaCT";
                    cmd.Parameters.AddWithValue("@MaHD", maHD);
                    cmd.Parameters.AddWithValue("@MaSP", maSP);
                    cmd.Parameters.AddWithValue("@SoLuong", soLuong);
                    cmd.Parameters.AddWithValue("@DonGia", donGia);
                    cmd.Parameters.AddWithValue("@ThanhTien", thanhTien);
                    cmd.Parameters.AddWithValue("@MaCT", maCT);

                    conn.Open();
                    var rows = cmd.ExecuteNonQuery();
                    if (rows == 0)
                        MessageBox.Show("Không tìm thấy chi tiết để cập nhật.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    else
                    {
                        LoadData();
                        MessageBox.Show("Cập nhật thành công.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi sửa: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            var maCT = txtMaChiTiet.Text.Trim();
            if (string.IsNullOrEmpty(maCT))
            {
                MessageBox.Show("Chọn chi tiết cần xóa.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (MessageBox.Show("Bạn có chắc muốn xóa chi tiết này?", "Xác nhận", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes)
                return;

            try
            {
                using (var conn = new SqlConnection(_connectionString))
                using (var cmd = conn.CreateCommand())
                {
                    cmd.CommandText = "DELETE FROM ChiTietHoaDon WHERE MaChiTietHoaDon = @MaCT";
                    cmd.Parameters.AddWithValue("@MaCT", maCT);
                    conn.Open();
                    var rows = cmd.ExecuteNonQuery();
                    if (rows == 0)
                        MessageBox.Show("Không tìm thấy chi tiết để xóa.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    else
                    {
                        LoadData();
                        MessageBox.Show("Xóa thành công.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi xóa: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnDong_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}