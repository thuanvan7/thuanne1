﻿
using System;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.Windows.Forms;

namespace QuanLyNhapVaBanHangTapHoa
{
    public partial class FormPhieuNhap : Form
    {
        // Chuỗi kết nối đầy đủ (theo yêu cầu)
        private readonly string _connectionStringFull =
            "Data Source=LAPTOP-QM4J7II6;Initial Catalog=QuanLyNhapVaBanHangTapHoa;Integrated Security=True;Encrypt=True;TrustServerCertificate=True";

        // Fallback nếu driver không hỗ trợ một số keyword
        private readonly string _connectionStringFallback =
            "Data Source=LAPTOP-QM4J7II6;Initial Catalog=QuanLyNhapVaBanHangTapHoa;Integrated Security=True";

        private string _connectionString; // chuỗi đang dùng
        private DataTable _dtPhieuNhap;

        public FormPhieuNhap()
        {
            InitializeComponent();
            this.Load += FormPhieuNhap_Load;
        }

        private void FormPhieuNhap_Load(object sender, EventArgs e)
        {
            _connectionString = GetWorkingConnectionString();
            if (string.IsNullOrEmpty(_connectionString))
            {
                MessageBox.Show("Không thể xác định chuỗi kết nối hợp lệ.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            LoadData();
        }

        private string GetWorkingConnectionString()
        {
            if (!string.IsNullOrEmpty(_connectionString)) return _connectionString;

            // Thử chuỗi đầy đủ trước
            try
            {
                using (var conn = new SqlConnection(_connectionStringFull))
                {
                    conn.Open();
                    conn.Close();
                }
                _connectionString = _connectionStringFull;
                return _connectionString;
            }
            catch (SqlException exFull)
            {
                var msg = exFull.Message ?? string.Empty;
                // Nếu lỗi do keyword không hỗ trợ, thử fallback
                if (msg.IndexOf("Keyword not supported", StringComparison.OrdinalIgnoreCase) >= 0
                    || msg.IndexOf("TrustServerCertificate", StringComparison.OrdinalIgnoreCase) >= 0
                    || msg.IndexOf("Encrypt", StringComparison.OrdinalIgnoreCase) >= 0)
                {
                    try
                    {
                        using (var conn = new SqlConnection(_connectionStringFallback))
                        {
                            conn.Open();
                            conn.Close();
                        }
                        _connectionString = _connectionStringFallback;
                        return _connectionString;
                    }
                    catch (Exception exFallback)
                    {
                        MessageBox.Show("Không thể kết nối với SQL Server bằng chuỗi fallback: " + exFallback.Message, "Lỗi kết nối", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return null;
                    }
                }

                MessageBox.Show("Lỗi khi thử chuỗi đầy đủ: " + exFull.Message, "Lỗi kết nối", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return null;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi kiểm tra chuỗi kết nối: " + ex.Message, "Lỗi kết nối", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return null;
            }
        }

        private void LoadData()
        {
            try
            {
                using (var conn = new SqlConnection(_connectionString))
                {
                    var sql = "SELECT MaPhieuNhap, NhaCungCap, NgayNhap FROM PhieuNhap";
                    using (var da = new SqlDataAdapter(sql, conn))
                    {
                        _dtPhieuNhap = new DataTable();
                        da.Fill(_dtPhieuNhap);
                        dgvPhieuNhap.DataSource = _dtPhieuNhap;
                    }
                }

                FormatGrid();
                ClearInputs();
            }
            catch (SqlException sqlEx)
            {
                MessageBox.Show("Lỗi khi tải dữ liệu (SQL): " + sqlEx.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi tải dữ liệu: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void FormatGrid()
        {
            dgvPhieuNhap.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvPhieuNhap.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvPhieuNhap.MultiSelect = false;
            dgvPhieuNhap.ReadOnly = true;
        }

        private void ClearInputs()
        {
            txtMaPhieuNhap.Text = "";
            txtNhaCungCap.Text = "";
            dtpNgayNhap.Value = DateTime.Today;
            txtMaPhieuNhap.Enabled = true;
        }

        private void dgvPhieuNhap_SelectionChanged(object sender, EventArgs e)
        {
            if (dgvPhieuNhap.CurrentRow == null) return;

            var row = dgvPhieuNhap.CurrentRow;
            txtMaPhieuNhap.Text = Convert.ToString(row.Cells["MaPhieuNhap"].Value);
            txtNhaCungCap.Text = Convert.ToString(row.Cells["NhaCungCap"].Value);

            var ngayObj = row.Cells["NgayNhap"].Value;
            if (ngayObj != DBNull.Value && DateTime.TryParse(Convert.ToString(ngayObj), out DateTime dt))
                dtpNgayNhap.Value = dt;
            else
                dtpNgayNhap.Value = DateTime.Today;

            txtMaPhieuNhap.Enabled = false;
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            var ma = txtMaPhieuNhap.Text.Trim();
            var ncc = txtNhaCungCap.Text.Trim();
            var ngay = dtpNgayNhap.Value.Date;

            if (string.IsNullOrEmpty(ma))
            {
                MessageBox.Show("Mã phiếu nhập không được để trống.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                using (var conn = new SqlConnection(_connectionString))
                using (var cmd = conn.CreateCommand())
                {
                    cmd.CommandText = "INSERT INTO PhieuNhap (MaPhieuNhap, NhaCungCap, NgayNhap) VALUES (@Ma, @NCC, @Ngay)";
                    cmd.Parameters.AddWithValue("@Ma", ma);
                    cmd.Parameters.AddWithValue("@NCC", string.IsNullOrEmpty(ncc) ? (object)DBNull.Value : ncc);
                    cmd.Parameters.AddWithValue("@Ngay", ngay);

                    conn.Open();
                    cmd.ExecuteNonQuery();
                }

                LoadData();
                MessageBox.Show("Thêm phiếu nhập thành công.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (SqlException ex) when (ex.Number == 2627)
            {
                MessageBox.Show("Mã phiếu nhập đã tồn tại.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi thêm: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            var ma = txtMaPhieuNhap.Text.Trim();
            if (string.IsNullOrEmpty(ma))
            {
                MessageBox.Show("Chọn phiếu cần sửa.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            var ncc = txtNhaCungCap.Text.Trim();
            var ngay = dtpNgayNhap.Value.Date;

            try
            {
                using (var conn = new SqlConnection(_connectionString))
                using (var cmd = conn.CreateCommand())
                {
                    cmd.CommandText = "UPDATE PhieuNhap SET NhaCungCap=@NCC, NgayNhap=@Ngay WHERE MaPhieuNhap=@Ma";
                    cmd.Parameters.AddWithValue("@NCC", string.IsNullOrEmpty(ncc) ? (object)DBNull.Value : ncc);
                    cmd.Parameters.AddWithValue("@Ngay", ngay);
                    cmd.Parameters.AddWithValue("@Ma", ma);

                    conn.Open();
                    var rows = cmd.ExecuteNonQuery();
                    if (rows == 0)
                        MessageBox.Show("Không tìm thấy phiếu để cập nhật.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    else
                    {
                        LoadData();
                        MessageBox.Show("Cập nhật thành công.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi sửa: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            var ma = txtMaPhieuNhap.Text.Trim();
            if (string.IsNullOrEmpty(ma))
            {
                MessageBox.Show("Chọn phiếu cần xóa.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (MessageBox.Show("Bạn có chắc muốn xóa phiếu này?", "Xác nhận", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes)
                return;

            try
            {
                using (var conn = new SqlConnection(_connectionString))
                using (var cmd = conn.CreateCommand())
                {
                    cmd.CommandText = "DELETE FROM PhieuNhap WHERE MaPhieuNhap = @Ma";
                    cmd.Parameters.AddWithValue("@Ma", ma);
                    conn.Open();
                    var rows = cmd.ExecuteNonQuery();
                    if (rows == 0)
                        MessageBox.Show("Không tìm thấy phiếu để xóa.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    else
                    {
                        LoadData();
                        MessageBox.Show("Xóa thành công.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi xóa: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnChiTiet_Click(object sender, EventArgs e)
        {
            var ma = txtMaPhieuNhap.Text.Trim();
            if (string.IsNullOrEmpty(ma))
            {
                MessageBox.Show("Chọn phiếu để xem chi tiết.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            // Hiện chi tiết đơn giản — bạn có thể mở form chi tiết riêng nếu cần.
            MessageBox.Show(string.Format("Chi tiết phiếu:\r\nMã: {0}\r\nNhà cung cấp: {1}\r\nNgày nhập: {2}",
                ma, txtNhaCungCap.Text, dtpNgayNhap.Value.ToShortDateString()), "Chi tiết phiếu", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnDong_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}