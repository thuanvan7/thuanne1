﻿
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace QuanLyNhapVaBanHangTapHoa
{
    partial class QuenMatKhau
    {
        private IContainer components = null;

        private Label lblHeader;
        private Label lblUsername;
        private Label lblEmail;
        private Label lblNewPassword;
        private Label lblConfirm;
        private TextBox txtUsername;
        private TextBox txtEmail;
        private TextBox txtNewPassword;
        private TextBox txtConfirm;
        private CheckBox chkShow;
        private Button btnReset;
        private Button btnCancel;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.components = new Container();

            this.lblHeader = new Label();
            this.lblUsername = new Label();
            this.lblEmail = new Label();
            this.lblNewPassword = new Label();
            this.lblConfirm = new Label();

            this.txtUsername = new TextBox();
            this.txtEmail = new TextBox();
            this.txtNewPassword = new TextBox();
            this.txtConfirm = new TextBox();

            this.chkShow = new CheckBox();
            this.btnReset = new Button();
            this.btnCancel = new Button();

            // Form
            this.ClientSize = new Size(460, 340);
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.StartPosition = FormStartPosition.CenterParent;
            this.Text = "Quên mật khẩu";

            // lblHeader
            this.lblHeader.Text = "QUÊN MẬT KHẨU";
            this.lblHeader.Font = new Font("Segoe UI", 14F, FontStyle.Bold);
            this.lblHeader.TextAlign = ContentAlignment.MiddleCenter;
            this.lblHeader.Size = new Size(440, 40);
            this.lblHeader.Location = new Point(10, 10);

            // lblUsername
            this.lblUsername.Text = "Tài khoản";
            this.lblUsername.Location = new Point(30, 70);
            this.lblUsername.Size = new Size(100, 22);

            this.txtUsername.Location = new Point(160, 68);
            this.txtUsername.Size = new Size(260, 24);

            // lblEmail
            this.lblEmail.Text = "Email (đăng ký)";
            this.lblEmail.Location = new Point(30, 110);
            this.lblEmail.Size = new Size(120, 22);

            this.txtEmail.Location = new Point(160, 108);
            this.txtEmail.Size = new Size(260, 24);

            // lblNewPassword
            this.lblNewPassword.Text = "Mật khẩu mới";
            this.lblNewPassword.Location = new Point(30, 150);
            this.lblNewPassword.Size = new Size(100, 22);

            this.txtNewPassword.Location = new Point(160, 148);
            this.txtNewPassword.Size = new Size(260, 24);
            this.txtNewPassword.UseSystemPasswordChar = true;

            // lblConfirm
            this.lblConfirm.Text = "Xác nhận";
            this.lblConfirm.Location = new Point(30, 190);
            this.lblConfirm.Size = new Size(100, 22);

            this.txtConfirm.Location = new Point(160, 188);
            this.txtConfirm.Size = new Size(260, 24);
            this.txtConfirm.UseSystemPasswordChar = true;

            // chkShow
            this.chkShow.Text = "Hiện mật khẩu";
            this.chkShow.Location = new Point(160, 220);
            this.chkShow.Size = new Size(120, 22);

            // btnReset
            this.btnReset.Text = "Đặt lại";
            this.btnReset.Location = new Point(160, 250);
            this.btnReset.Size = new Size(110, 36);

            // btnCancel
            this.btnCancel.Text = "Hủy";
            this.btnCancel.Location = new Point(310, 250);
            this.btnCancel.Size = new Size(110, 36);

            // add controls
            this.Controls.Add(this.lblHeader);
            this.Controls.Add(this.lblUsername);
            this.Controls.Add(this.txtUsername);
            this.Controls.Add(this.lblEmail);
            this.Controls.Add(this.txtEmail);
            this.Controls.Add(this.lblNewPassword);
            this.Controls.Add(this.txtNewPassword);
            this.Controls.Add(this.lblConfirm);
            this.Controls.Add(this.txtConfirm);
            this.Controls.Add(this.chkShow);
            this.Controls.Add(this.btnReset);
            this.Controls.Add(this.btnCancel);
        }
    }
}