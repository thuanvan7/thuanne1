﻿
using System;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.Linq;
using System.Windows.Forms;

namespace QuanLyNhapVaBanHangTapHoa
{
    public partial class FormHoaDon : Form
    {
        private readonly string _connectionStringFull =
            "Data Source=LAPTOP-QM4J7II6;Initial Catalog=QuanLyNhapVaBanHangTapHoa;Integrated Security=True;Encrypt=True;TrustServerCertificate=True";

        private readonly string _connectionStringFallback =
            "Data Source=LAPTOP-QM4J7II6;Initial Catalog=QuanLyNhapVaBanHangTapHoa;Integrated Security=True";

        private string _connectionString;
        private DataTable _dtHoaDon;

        public FormHoaDon()
        {
            InitializeComponent();
            this.Load += FormHoaDon_Load;
        }

        private void FormHoaDon_Load(object sender, EventArgs e)
        {
            _connectionString = GetWorkingConnectionString();
            if (string.IsNullOrEmpty(_connectionString))
            {
                MessageBox.Show("Không xác định được chuỗi kết nối hợp lệ.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            LoadData();
        }

        private string GetWorkingConnectionString()
        {
            if (!string.IsNullOrEmpty(_connectionString)) return _connectionString;

            try
            {
                using (var conn = new SqlConnection(_connectionStringFull))
                {
                    conn.Open();
                    conn.Close();
                }
                _connectionString = _connectionStringFull;
                return _connectionString;
            }
            catch (SqlException exFull)
            {
                var msg = exFull.Message ?? string.Empty;
                if (msg.IndexOf("Keyword not supported", StringComparison.OrdinalIgnoreCase) >= 0
                    || msg.IndexOf("TrustServerCertificate", StringComparison.OrdinalIgnoreCase) >= 0
                    || msg.IndexOf("Encrypt", StringComparison.OrdinalIgnoreCase) >= 0)
                {
                    try
                    {
                        using (var conn = new SqlConnection(_connectionStringFallback))
                        {
                            conn.Open();
                            conn.Close();
                        }
                        _connectionString = _connectionStringFallback;
                        return _connectionString;
                    }
                    catch (Exception exFallback)
                    {
                        MessageBox.Show("Không thể kết nối với SQL Server bằng chuỗi fallback: " + exFallback.Message, "Lỗi kết nối", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return null;
                    }
                }

                MessageBox.Show("Lỗi khi thử chuỗi đầy đủ: " + exFull.Message, "Lỗi kết nối", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return null;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi kiểm tra chuỗi kết nối: " + ex.Message, "Lỗi kết nối", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return null;
            }
        }

        private void LoadData()
        {
            try
            {
                using (var conn = new SqlConnection(_connectionString))
                {
                    var sql = "SELECT MaHoaDon, NgayLap, TenKhachHang, TongTien FROM HoaDon";
                    using (var da = new SqlDataAdapter(sql, conn))
                    {
                        _dtHoaDon = new DataTable();
                        da.Fill(_dtHoaDon);
                        dgvHoaDon.DataSource = _dtHoaDon;
                    }
                }

                FormatGrid();
                ClearInputs();
            }
            catch (SqlException sqlEx)
            {
                MessageBox.Show("Lỗi khi tải dữ liệu (SQL): " + sqlEx.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi tải dữ liệu: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void FormatGrid()
        {
            dgvHoaDon.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvHoaDon.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvHoaDon.MultiSelect = false;
            dgvHoaDon.ReadOnly = true;
        }

        private void ClearInputs()
        {
            txtMaHoaDon.Text = "";
            dtpNgayLap.Value = DateTime.Today;
            txtTenKhachHang.Text = "";
            txtTongTien.Text = "0.00";
            txtMaHoaDon.Enabled = true;
        }

        private void dgvHoaDon_SelectionChanged(object sender, EventArgs e)
        {
            if (dgvHoaDon.CurrentRow == null) return;

            var row = dgvHoaDon.CurrentRow;
            txtMaHoaDon.Text = Convert.ToString(row.Cells["MaHoaDon"].Value);

            var ngayObj = row.Cells["NgayLap"].Value;
            if (ngayObj != DBNull.Value && DateTime.TryParse(Convert.ToString(ngayObj), out DateTime dt))
                dtpNgayLap.Value = dt;
            else
                dtpNgayLap.Value = DateTime.Today;

            txtTenKhachHang.Text = Convert.ToString(row.Cells["TenKhachHang"].Value);
            txtTongTien.Text = Convert.ToString(row.Cells["TongTien"].Value);

            txtMaHoaDon.Enabled = false;
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            var ma = txtMaHoaDon.Text.Trim();
            var ngay = dtpNgayLap.Value.Date;
            var tenKH = txtTenKhachHang.Text.Trim();

            if (string.IsNullOrEmpty(ma))
            {
                MessageBox.Show("Mã hóa đơn không được để trống.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!decimal.TryParse(txtTongTien.Text.Trim(), NumberStyles.Number, CultureInfo.CurrentCulture, out decimal tongTien))
            {
                MessageBox.Show("Tổng tiền không đúng định dạng.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                using (var conn = new SqlConnection(_connectionString))
                using (var cmd = conn.CreateCommand())
                {
                    cmd.CommandText = "INSERT INTO HoaDon (MaHoaDon, NgayLap, TenKhachHang, TongTien) " +
                                      "VALUES (@Ma, @Ngay, @TenKH, @Tong)";
                    cmd.Parameters.AddWithValue("@Ma", ma);
                    cmd.Parameters.AddWithValue("@Ngay", ngay);
                    cmd.Parameters.AddWithValue("@TenKH", string.IsNullOrEmpty(tenKH) ? (object)DBNull.Value : tenKH);
                    cmd.Parameters.AddWithValue("@Tong", tongTien);

                    conn.Open();
                    cmd.ExecuteNonQuery();
                }

                LoadData();
                MessageBox.Show("Thêm hóa đơn thành công.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (SqlException ex) when (ex.Number == 2627)
            {
                MessageBox.Show("Mã hóa đơn đã tồn tại.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi thêm: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            var ma = txtMaHoaDon.Text.Trim();
            if (string.IsNullOrEmpty(ma))
            {
                MessageBox.Show("Chọn hóa đơn cần sửa.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            var ngay = dtpNgayLap.Value.Date;
            var tenKH = txtTenKhachHang.Text.Trim();

            if (!decimal.TryParse(txtTongTien.Text.Trim(), NumberStyles.Number, CultureInfo.CurrentCulture, out decimal tongTien))
            {
                MessageBox.Show("Tổng tiền không đúng định dạng.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                using (var conn = new SqlConnection(_connectionString))
                using (var cmd = conn.CreateCommand())
                {
                    cmd.CommandText = "UPDATE HoaDon SET NgayLap=@Ngay, TenKhachHang=@TenKH, TongTien=@Tong WHERE MaHoaDon=@Ma";
                    cmd.Parameters.AddWithValue("@Ngay", ngay);
                    cmd.Parameters.AddWithValue("@TenKH", string.IsNullOrEmpty(tenKH) ? (object)DBNull.Value : tenKH);
                    cmd.Parameters.AddWithValue("@Tong", tongTien);
                    cmd.Parameters.AddWithValue("@Ma", ma);

                    conn.Open();
                    var rows = cmd.ExecuteNonQuery();
                    if (rows == 0)
                        MessageBox.Show("Không tìm thấy hóa đơn để cập nhật.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    else
                    {
                        LoadData();
                        MessageBox.Show("Cập nhật thành công.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi sửa: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            var ma = txtMaHoaDon.Text.Trim();
            if (string.IsNullOrEmpty(ma))
            {
                MessageBox.Show("Chọn hóa đơn cần xóa.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (MessageBox.Show("Bạn có chắc muốn xóa hóa đơn này?", "Xác nhận", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes)
                return;

            try
            {
                using (var conn = new SqlConnection(_connectionString))
                using (var cmd = conn.CreateCommand())
                {
                    cmd.CommandText = "DELETE FROM HoaDon WHERE MaHoaDon = @Ma";
                    cmd.Parameters.AddWithValue("@Ma", ma);
                    conn.Open();
                    var rows = cmd.ExecuteNonQuery();
                    if (rows == 0)
                        MessageBox.Show("Không tìm thấy hóa đơn để xóa.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    else
                    {
                        LoadData();
                        MessageBox.Show("Xóa thành công.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi xóa: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnChiTiet_Click(object sender, EventArgs e)
        {
            // Lấy mã hóa đơn đang chọn (ưu tiên DataGridView selection)
            string ma = txtMaHoaDon.Text.Trim();
            if (dgvHoaDon.CurrentRow != null)
            {
                var cell = dgvHoaDon.CurrentRow.Cells["MaHoaDon"];
                if (cell != null && cell.Value != null)
                    ma = Convert.ToString(cell.Value);
            }

            if (string.IsNullOrEmpty(ma))
            {
                MessageBox.Show("Vui lòng chọn hoặc nhập Mã Hóa Đơn để xem chi tiết.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            try
            {
                // Mở FormChiTietHoaDon và truyền mã hóa đơn (nếu form hỗ trợ)
                var f = new FormChiTietHoaDon(ma);
                // Nếu app dùng MDI, đặt MdiParent giống parent hiện tại
                if (this.MdiParent != null)
                    f.MdiParent = this.MdiParent;
                f.StartPosition = FormStartPosition.CenterParent;
                f.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi mở chi tiết hóa đơn: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnDong_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}