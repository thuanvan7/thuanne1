﻿
using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace QuanLyNhapVaBanHangTapHoa
{
    public partial class DangNhap : Form
    {
        // Use simple connection string (no unsupported keywords)
        private readonly string _connectionString =
            "Data Source=LAPTOP-QM4J7II6;Initial Catalog=QuanLyNhapVaBanHangTapHoa;Integrated Security=True";

        public DangNhap()
        {
            InitializeComponent();

            btnDangNhap.Click += BtnDangNhap_Click;
            btnQuenMatKhau.Click += BtnQuenMatKhau_Click; // new handler
            chkShowPassword.CheckedChanged += ChkShowPassword_CheckedChanged;

            // initial state
            txtPassword.UseSystemPasswordChar = true;
        }

        private void ChkShowPassword_CheckedChanged(object sender, EventArgs e)
        {
            txtPassword.UseSystemPasswordChar = !chkShowPassword.Checked;
        }

        private void BtnDangNhap_Click(object sender, EventArgs e)
        {
            string username = txtUsername.Text.Trim();
            string password = txtPassword.Text.Trim();

            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
            {
                MessageBox.Show("Vui lòng nhập đầy đủ thông tin.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                using (SqlConnection conn = new SqlConnection(_connectionString))
                using (SqlCommand cmd = conn.CreateCommand())
                {
                    conn.Open();
                    cmd.CommandText = "SELECT COUNT(*) FROM TaiKhoan WHERE TaiKhoan = @TaiKhoan AND MatKhau = @MatKhau";
                    cmd.Parameters.AddWithValue("@TaiKhoan", username);
                    cmd.Parameters.AddWithValue("@MatKhau", password);

                    int count = Convert.ToInt32(cmd.ExecuteScalar() ?? 0);
                    if (count > 0)
                    {
                        var mainForm = new FormMDI();
                        mainForm.FormClosed += (s, args) => this.Close();
                        mainForm.Show();
                        this.Hide();
                    }
                    else
                    {
                        MessageBox.Show("Tên đăng nhập hoặc mật khẩu không đúng.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi kết nối hoặc truy vấn cơ sở dữ liệu: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // New: open password recovery form
        private void BtnQuenMatKhau_Click(object sender, EventArgs e)
        {
            using (var f = new QuenMatKhau())
            {
                f.ShowDialog(this);
            }
        }
    }
}