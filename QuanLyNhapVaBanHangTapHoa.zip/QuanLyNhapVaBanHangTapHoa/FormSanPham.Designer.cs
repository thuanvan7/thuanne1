﻿
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace QuanLyNhapVaBanHangTapHoa
{
    partial class FormSanPham
    {
        private IContainer components = null;

        private Panel panelLeft;
        private Label lblHeader;
        private Label lblMaSanPham;
        private Label lblTenSanPham;
        private Label lblSoLuongLon;
        private Label lblGiaBan;
        private Label lblDonViTinh;
        private Label lblTenLoai;

        private TextBox txtMaSanPham;
        private TextBox txtTenSanPham;
        private TextBox txtSoLuongLon;
        private TextBox txtGiaBan;
        private TextBox txtDonViTinh;
        private TextBox txtTenLoai;

        private Button btnThem;
        private Button btnSua;
        private Button btnXoa;
        private Button btnDong;

        private DataGridView dgvSanPham;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.panelLeft = new System.Windows.Forms.Panel();
            this.lblHeader = new System.Windows.Forms.Label();
            this.lblMaSanPham = new System.Windows.Forms.Label();
            this.txtMaSanPham = new System.Windows.Forms.TextBox();
            this.lblTenSanPham = new System.Windows.Forms.Label();
            this.txtTenSanPham = new System.Windows.Forms.TextBox();
            this.lblSoLuongLon = new System.Windows.Forms.Label();
            this.txtSoLuongLon = new System.Windows.Forms.TextBox();
            this.lblGiaBan = new System.Windows.Forms.Label();
            this.txtGiaBan = new System.Windows.Forms.TextBox();
            this.lblDonViTinh = new System.Windows.Forms.Label();
            this.txtDonViTinh = new System.Windows.Forms.TextBox();
            this.lblTenLoai = new System.Windows.Forms.Label();
            this.txtTenLoai = new System.Windows.Forms.TextBox();
            this.btnThem = new System.Windows.Forms.Button();
            this.btnSua = new System.Windows.Forms.Button();
            this.btnXoa = new System.Windows.Forms.Button();
            this.btnDong = new System.Windows.Forms.Button();
            this.dgvSanPham = new System.Windows.Forms.DataGridView();
            this.panelLeft.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSanPham)).BeginInit();
            this.SuspendLayout();
            // 
            // panelLeft
            // 
            this.panelLeft.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.panelLeft.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelLeft.Controls.Add(this.lblHeader);
            this.panelLeft.Controls.Add(this.lblMaSanPham);
            this.panelLeft.Controls.Add(this.txtMaSanPham);
            this.panelLeft.Controls.Add(this.lblTenSanPham);
            this.panelLeft.Controls.Add(this.txtTenSanPham);
            this.panelLeft.Controls.Add(this.lblSoLuongLon);
            this.panelLeft.Controls.Add(this.txtSoLuongLon);
            this.panelLeft.Controls.Add(this.lblGiaBan);
            this.panelLeft.Controls.Add(this.txtGiaBan);
            this.panelLeft.Controls.Add(this.lblDonViTinh);
            this.panelLeft.Controls.Add(this.txtDonViTinh);
            this.panelLeft.Controls.Add(this.lblTenLoai);
            this.panelLeft.Controls.Add(this.txtTenLoai);
            this.panelLeft.Controls.Add(this.btnThem);
            this.panelLeft.Controls.Add(this.btnSua);
            this.panelLeft.Controls.Add(this.btnXoa);
            this.panelLeft.Controls.Add(this.btnDong);
            this.panelLeft.Location = new System.Drawing.Point(8, 8);
            this.panelLeft.Name = "panelLeft";
            this.panelLeft.Size = new System.Drawing.Size(340, 634);
            this.panelLeft.TabIndex = 0;
            // 
            // lblHeader
            // 
            this.lblHeader.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblHeader.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold);
            this.lblHeader.Location = new System.Drawing.Point(0, 0);
            this.lblHeader.Name = "lblHeader";
            this.lblHeader.Size = new System.Drawing.Size(338, 50);
            this.lblHeader.TabIndex = 0;
            this.lblHeader.Text = "Quản lý sản phẩm";
            this.lblHeader.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblMaSanPham
            // 
            this.lblMaSanPham.Location = new System.Drawing.Point(12, 70);
            this.lblMaSanPham.Name = "lblMaSanPham";
            this.lblMaSanPham.Size = new System.Drawing.Size(100, 22);
            this.lblMaSanPham.TabIndex = 1;
            this.lblMaSanPham.Text = "Mã sản phẩm";
            // 
            // txtMaSanPham
            // 
            this.txtMaSanPham.Location = new System.Drawing.Point(112, 68);
            this.txtMaSanPham.Name = "txtMaSanPham";
            this.txtMaSanPham.Size = new System.Drawing.Size(200, 22);
            this.txtMaSanPham.TabIndex = 2;
            // 
            // lblTenSanPham
            // 
            this.lblTenSanPham.Location = new System.Drawing.Point(12, 118);
            this.lblTenSanPham.Name = "lblTenSanPham";
            this.lblTenSanPham.Size = new System.Drawing.Size(100, 22);
            this.lblTenSanPham.TabIndex = 3;
            this.lblTenSanPham.Text = "Tên sản phẩm";
            // 
            // txtTenSanPham
            // 
            this.txtTenSanPham.Location = new System.Drawing.Point(112, 116);
            this.txtTenSanPham.Name = "txtTenSanPham";
            this.txtTenSanPham.Size = new System.Drawing.Size(200, 22);
            this.txtTenSanPham.TabIndex = 4;
            // 
            // lblSoLuongLon
            // 
            this.lblSoLuongLon.Location = new System.Drawing.Point(12, 166);
            this.lblSoLuongLon.Name = "lblSoLuongLon";
            this.lblSoLuongLon.Size = new System.Drawing.Size(100, 22);
            this.lblSoLuongLon.TabIndex = 5;
            this.lblSoLuongLon.Text = "Số lượng lớn";
            // 
            // txtSoLuongLon
            // 
            this.txtSoLuongLon.Location = new System.Drawing.Point(112, 164);
            this.txtSoLuongLon.Name = "txtSoLuongLon";
            this.txtSoLuongLon.Size = new System.Drawing.Size(200, 22);
            this.txtSoLuongLon.TabIndex = 6;
            // 
            // lblGiaBan
            // 
            this.lblGiaBan.Location = new System.Drawing.Point(12, 214);
            this.lblGiaBan.Name = "lblGiaBan";
            this.lblGiaBan.Size = new System.Drawing.Size(100, 22);
            this.lblGiaBan.TabIndex = 7;
            this.lblGiaBan.Text = "Giá bán";
            // 
            // txtGiaBan
            // 
            this.txtGiaBan.Location = new System.Drawing.Point(112, 212);
            this.txtGiaBan.Name = "txtGiaBan";
            this.txtGiaBan.Size = new System.Drawing.Size(200, 22);
            this.txtGiaBan.TabIndex = 8;
            // 
            // lblDonViTinh
            // 
            this.lblDonViTinh.Location = new System.Drawing.Point(12, 262);
            this.lblDonViTinh.Name = "lblDonViTinh";
            this.lblDonViTinh.Size = new System.Drawing.Size(100, 22);
            this.lblDonViTinh.TabIndex = 9;
            this.lblDonViTinh.Text = "Đơn vị tính";
            // 
            // txtDonViTinh
            // 
            this.txtDonViTinh.Location = new System.Drawing.Point(112, 260);
            this.txtDonViTinh.Name = "txtDonViTinh";
            this.txtDonViTinh.Size = new System.Drawing.Size(200, 22);
            this.txtDonViTinh.TabIndex = 10;
            // 
            // lblTenLoai
            // 
            this.lblTenLoai.Location = new System.Drawing.Point(12, 310);
            this.lblTenLoai.Name = "lblTenLoai";
            this.lblTenLoai.Size = new System.Drawing.Size(100, 22);
            this.lblTenLoai.TabIndex = 11;
            this.lblTenLoai.Text = "Tên Loại";
            // 
            // txtTenLoai
            // 
            this.txtTenLoai.Location = new System.Drawing.Point(112, 308);
            this.txtTenLoai.Name = "txtTenLoai";
            this.txtTenLoai.Size = new System.Drawing.Size(200, 22);
            this.txtTenLoai.TabIndex = 12;
            // 
            // btnThem
            // 
            this.btnThem.Location = new System.Drawing.Point(12, 420);
            this.btnThem.Name = "btnThem";
            this.btnThem.Size = new System.Drawing.Size(80, 32);
            this.btnThem.TabIndex = 13;
            this.btnThem.Text = "Thêm";
            this.btnThem.Click += new System.EventHandler(this.btnThem_Click);
            // 
            // btnSua
            // 
            this.btnSua.Location = new System.Drawing.Point(104, 420);
            this.btnSua.Name = "btnSua";
            this.btnSua.Size = new System.Drawing.Size(80, 32);
            this.btnSua.TabIndex = 14;
            this.btnSua.Text = "Sửa";
            this.btnSua.Click += new System.EventHandler(this.btnSua_Click);
            // 
            // btnXoa
            // 
            this.btnXoa.Location = new System.Drawing.Point(196, 420);
            this.btnXoa.Name = "btnXoa";
            this.btnXoa.Size = new System.Drawing.Size(80, 32);
            this.btnXoa.TabIndex = 15;
            this.btnXoa.Text = "Xóa";
            this.btnXoa.Click += new System.EventHandler(this.btnXoa_Click);
            // 
            // btnDong
            // 
            this.btnDong.Location = new System.Drawing.Point(288, 420);
            this.btnDong.Name = "btnDong";
            this.btnDong.Size = new System.Drawing.Size(80, 32);
            this.btnDong.TabIndex = 16;
            this.btnDong.Text = "Đóng";
            this.btnDong.Click += new System.EventHandler(this.btnDong_Click);
            // 
            // dgvSanPham
            // 
            this.dgvSanPham.AllowUserToAddRows = false;
            this.dgvSanPham.AllowUserToDeleteRows = false;
            this.dgvSanPham.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvSanPham.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.dgvSanPham.ColumnHeadersHeight = 29;
            this.dgvSanPham.Location = new System.Drawing.Point(360, 8);
            this.dgvSanPham.MultiSelect = false;
            this.dgvSanPham.Name = "dgvSanPham";
            this.dgvSanPham.ReadOnly = true;
            this.dgvSanPham.RowHeadersWidth = 51;
            this.dgvSanPham.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvSanPham.Size = new System.Drawing.Size(632, 634);
            this.dgvSanPham.TabIndex = 1;
            this.dgvSanPham.SelectionChanged += new System.EventHandler(this.dgvSanPham_SelectionChanged);
            // 
            // FormSanPham
            // 
            this.ClientSize = new System.Drawing.Size(1000, 650);
            this.Controls.Add(this.panelLeft);
            this.Controls.Add(this.dgvSanPham);
            this.Name = "FormSanPham";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Quản lý sản phẩm";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.panelLeft.ResumeLayout(false);
            this.panelLeft.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSanPham)).EndInit();
            this.ResumeLayout(false);

        }
    }
}