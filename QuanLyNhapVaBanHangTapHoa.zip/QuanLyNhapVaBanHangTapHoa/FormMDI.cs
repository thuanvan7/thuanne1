﻿using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace QuanLyNhapVaBanHangTapHoa
{
    public partial class FormMDI : Form
    {
        public FormMDI()
        {
            InitializeComponent();

            // Wire click events safely (designer usually wires these already)
            if (btnProducts != null) { btnProducts.Click -= btnProducts_Click; btnProducts.Click += btnProducts_Click; }
            if (btnImport != null) { btnImport.Click -= btnImport_Click; btnImport.Click += btnImport_Click; }
            if (btnInvoice != null) { btnInvoice.Click -= btnInvoice_Click; btnInvoice.Click += btnInvoice_Click; }
            if (btnReports != null) { btnReports.Click -= btnReports_Click; btnReports.Click += btnReports_Click; }
            if (btnExit != null) { btnExit.Click -= btnExit_Click; btnExit.Click += btnExit_Click; }
        }

        // Open or activate generic MDI child (parameterless ctor)
        private void OpenOrActivate<T>() where T : Form, new()
        {
            try
            {
                var existing = this.MdiChildren.OfType<T>().FirstOrDefault();
                if (existing != null)
                {
                    if (existing.WindowState == FormWindowState.Minimized) existing.WindowState = FormWindowState.Normal;
                    existing.BringToFront();
                    existing.Activate();
                    return;
                }

                var child = new T
                {
                    MdiParent = this,
                    WindowState = FormWindowState.Normal
                };

                ShowChildSafely(child);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi mở form: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Open or activate form by Type (supports ctor with params)
        private void OpenOrActivate(Type formType, params object[] ctorArgs)
        {
            try
            {
                var existing = this.MdiChildren.FirstOrDefault(f => f.GetType() == formType);
                if (existing != null)
                {
                    if (existing.WindowState == FormWindowState.Minimized) existing.WindowState = FormWindowState.Normal;
                    existing.BringToFront();
                    existing.Activate();
                    return;
                }

                Form instance = (ctorArgs == null || ctorArgs.Length == 0)
                    ? Activator.CreateInstance(formType) as Form
                    : Activator.CreateInstance(formType, ctorArgs) as Form;

                if (instance == null)
                {
                    MessageBox.Show("Không thể tạo instance của form " + formType.FullName, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                instance.MdiParent = this;
                instance.WindowState = FormWindowState.Normal;

                ShowChildSafely(instance);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi mở form: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Display child safely, fallback embed if necessary
        private void ShowChildSafely(Form child)
        {
            try
            {
                child.Show();

                if (!child.Visible)
                {
                    var panelMain = this.Controls.Find("panelMain", true).FirstOrDefault() as Control;
                    if (panelMain != null)
                        EmbedFormIntoPanel(child, panelMain);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi hiển thị form: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void EmbedFormIntoPanel(Form form, Control panel)
        {
            if (form == null || panel == null) return;

            form.Hide();
            form.TopLevel = false;
            form.FormBorderStyle = FormBorderStyle.None;
            form.Dock = DockStyle.Fill;
            panel.Controls.Clear();
            panel.Controls.Add(form);
            form.Show();
        }

        private void btnProducts_Click(object sender, EventArgs e)
        {
            OpenOrActivate<FormSanPham>();
        }

        private void btnImport_Click(object sender, EventArgs e)
        {
            OpenOrActivate<FormPhieuNhap>();
        }

        private void btnInvoice_Click(object sender, EventArgs e)
        {
            OpenOrActivate<FormHoaDon>();
        }

        private void btnReports_Click(object sender, EventArgs e)
        {
            OpenOrActivate<FormThongKe>();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Bạn có chắc muốn thoát?", "Xác nhận", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                Application.Exit();
        }
    }
}